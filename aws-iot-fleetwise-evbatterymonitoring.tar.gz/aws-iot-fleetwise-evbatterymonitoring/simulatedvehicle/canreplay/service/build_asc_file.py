import cantools
import can

# Flags
PROCESS_ONLY_DESIRED_IDS = False  # Change to False if you want to process all IDs
WRITE_TO_FILE = True  # Change to False if you only want to display the messages without writing to a new file

datadir = "/home/ubuntu/aws-iot-fleetwise-evbatterymonitoring/simulatedvehicle/canreplay/config/vin100/ev_overcurrent_detection/"
dbc_file_name = datadir + "ev_overcurrent_detection.dbc"
asc_file_name = datadir + "ev_overcurrent_detection_OG.asc"
#asc_file_name = datadir + "ev_overcurrent_detection_previous.asc" #to check what you have written in the new file
new_asc_file_name = datadir + "ev_overcurrent_detection.asc"


# Load dbc file to database
db = cantools.database.load_file(dbc_file_name)

# Define the list of arbitration IDs specific to your use case
desired_ids = [3, 257, 768] if PROCESS_ONLY_DESIRED_IDS else None

# Process and write messages
with can.ASCWriter(new_asc_file_name, mode='w') as writer:
    with can.ASCReader(asc_file_name) as asclog:
        for mesg in asclog:
            if PROCESS_ONLY_DESIRED_IDS and desired_ids is not None and mesg.arbitration_id not in desired_ids:
                continue

            try:
                original_msg_data = db.decode_message(mesg.arbitration_id, mesg.data)
                print(f"Original ID {mesg.arbitration_id}: {original_msg_data}")

                # Modify the message if necessary
                modified_msg_data = original_msg_data.copy()
                if mesg.arbitration_id == 257:
                    original_soh = modified_msg_data['StateOfHealth']
                    modified_msg_data['StateOfHealth'] = max(original_soh - 2, 0)
                    print(f"Updated SOH: {modified_msg_data['StateOfHealth']}")

                # Encode the modified message back into bytes
                encoded_msg = db.encode_message(mesg.arbitration_id, modified_msg_data, scaling=True, padding=False, strict=False)
                new_message = can.Message(
                    arbitration_id=mesg.arbitration_id,
                    data=encoded_msg,
                    timestamp=mesg.timestamp,
                    is_extended_id=mesg.is_extended_id
                )

                print(f"Modified ID {mesg.arbitration_id}: {modified_msg_data}")

                if WRITE_TO_FILE:
                    # Write the new message to the ASC file using ASCWriter
                    writer.on_message_received(new_message)

            except KeyError:
                print(f"KeyError: Message with arbitration ID {mesg.arbitration_id} not found in DBC.")
            except Exception as e:
                print(f"Exception: {e}")

print(f"Finished processing. {'Output written to ' + new_asc_file_name if WRITE_TO_FILE else 'No output file written.'}")