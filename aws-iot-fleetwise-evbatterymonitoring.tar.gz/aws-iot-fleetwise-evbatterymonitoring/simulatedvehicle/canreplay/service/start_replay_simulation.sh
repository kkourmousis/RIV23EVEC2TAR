#!/bin/sh

PYTHON_SCRIPT="./build_asc_file.py"

chmod +x $PYTHON_SCRIPT

/bin/python3 $PYTHON_SCRIPT

asc2log -I /home/ubuntu/aws-iot-fleetwise-evbatterymonitoring/simulatedvehicle/canreplay/config/vin100/ev_overcurrent_detection/ev_overcurrent_detection.asc -O /home/ubuntu/aws-iot-fleetwise-evbatterymonitoring/simulatedvehicle/canreplay/config/vin100/ev_overcurrent_detection/ev_overcurrent_detection.log

canplayer -I /home/ubuntu/aws-iot-fleetwise-evbatterymonitoring/simulatedvehicle/canreplay/config/vin100/ev_overcurrent_detection/ev_overcurrent_detection.log vcan0=can0