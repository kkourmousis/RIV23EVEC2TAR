#!/bin/sh

#asc2log -I /home/ubuntu/aws-iot-fleetwise-evbatterymonitoring/simulatedvehicle/canreplay/config/vin100/ev_overcurrent_detection/ev_overcurrent_detection.asc -O /home/ubuntu/aws-iot-fleetwise-evbatterymonitoring/simulatedvehicle/canreplay/config/vin100/ev_overcurrent_detection/ev_overcurrent_detection.log
canplayer -I /home/ubuntu/aws-iot-fleetwise-evbatterymonitoring/simulatedvehicle/canreplay/config/vin100/ev_overcurrent_detection/ev_overcurrent_detection.log vcan0=can0
#cantools monitor -c vcan0 --single-line /home/ubuntu/aws-iot-fleetwise-evbatterymonitoring/simulatedvehicle/canreplay/config/vin100/ev_overcurrent_detection/ev_overcurrent_detection.dbc